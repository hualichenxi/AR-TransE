package com.zzq.ruleminer;


public class Int
{
    public long value = 0;
    
    public Int(long value) {
        this.value = value;
    }
}